# Sample Threat Model — Personal Digital Footprint

**Subject:** Redacted (for privacy)
**Date:** 2024
**Methodology:** Passive OSINT — No active scanning
**Classification:** Educational / Portfolio

---

## Executive Summary

Analysis of two Gmail addresses sharing a consistent username pattern revealed a **CRITICAL** overall risk level. The primary threat vectors are:

1. **Data broker aggregation** — PII indexed and cross-referenced
2. **Username fingerprinting** — Consistent pattern enables automated enumeration
3. **Breach database exposure** — Gmail addresses present in multiple breach datasets

Fourteen platforms were assessed. Three were categorised as critical exposure surfaces, eight as high-probability exposure, and three as lower risk.

---

## Risk Vector Summary

| Vector | Severity | Score |
|---|---|---|
| Data broker exposure | CRITICAL | 95/100 |
| Username enumeration | CRITICAL | 92/100 |
| Credential breach databases | HIGH | 78/100 |
| Cross-platform identity correlation | HIGH | 74/100 |
| Public records linkage | MEDIUM | 55/100 |
| Social engineering surface | MEDIUM | 50/100 |
| Google account enumeration | MEDIUM | 45/100 |
| File metadata leakage | LOW | 28/100 |

---

## Key Findings

### Finding 1 — Username Pattern Cross-Correlation [CRITICAL]

The use of a predictable `[name][numbers]` pattern across both email addresses creates a high-confidence fingerprint. Automated tools can enumerate this pattern across hundreds of platforms without any authentication, revealing:
- Account existence on social media platforms
- Associated profile photos and real names
- Activity history and connections

**Recommendation:** Adopt platform-specific random usernames stored in a password manager.

### Finding 2 — Dual Email Attack Surface [HIGH]

Operating two email addresses with the same numeric suffix doubles the attack surface. If either address appears in a breach, adversaries will automatically test the variant. Both addresses should be treated as equally sensitive identifiers.

**Recommendation:** Consolidate to one primary address; use aliases for service sign-ups.

### Finding 3 — Google Account Public Exposure [MEDIUM]

Google accounts expose data through multiple surfaces that users typically overlook:
- Google Maps reviews display full name and profile photo
- YouTube comments are publicly indexed
- Calendar sharing links may be discoverable
- Google Photos albums can be accidentally shared

**Recommendation:** Audit all Google account privacy settings at myaccount.google.com.

---

## Remediation Roadmap

### Immediate (Week 1)
- [ ] Run both emails through HaveIBeenPwned
- [ ] Lock down Google public profile
- [ ] Enable GitHub commit email privacy

### Short Term (Month 1)
- [ ] Opt out of top 5 data brokers
- [ ] Run Sherlock username enumeration and audit results
- [ ] Enable 2FA on all critical accounts

### Ongoing
- [ ] Adopt unique usernames per platform going forward
- [ ] Use email aliases for new service sign-ups
- [ ] Set Google Alerts for name and email monitoring

---

## Tools Used

All tools used in this analysis are open-source and freely available:

- **Sherlock** — username enumeration
- **GHunt** — Google account profiling
- **HaveIBeenPwned** — breach lookup
- **Google Advanced Search** — dorking
- **OSINT Framework** — methodology reference

---

*This report was produced for educational and portfolio purposes. No active exploitation was performed.*
