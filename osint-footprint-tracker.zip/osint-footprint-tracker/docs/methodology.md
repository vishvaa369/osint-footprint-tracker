# OSINT Methodology — Digital Footprint Analysis

## Overview

This document outlines the passive reconnaissance methodology used in this project. All phases use **open-source, non-intrusive** techniques that do not require direct system access.

---

## Phase 1 — Target Identification

### Inputs
- Email address(es)
- Known usernames
- Real name (optional)

### Tasks
1. Extract username pattern (base + suffix)
2. Identify email domain and provider
3. Map numeric/special character patterns for enumeration

### Tools
- Manual analysis
- `username-anarchy` for variant generation

---

## Phase 2 — Passive Footprint Mapping

### 2.1 Username Enumeration
```bash
# Sherlock
python3 sherlock <username>

# Maigret (more detailed)
python3 -m maigret <username> --html
```

### 2.2 Email Reconnaissance
```bash
# theHarvester
theHarvester -d gmail.com -b google -l 200

# Google dork manually
"target@gmail.com" site:pastebin.com
"target@gmail.com" filetype:pdf
```

### 2.3 Breach Check
- [HaveIBeenPwned](https://haveibeenpwned.com) — API available
- [DeHashed](https://dehashed.com) — subscription for plaintext
- [IntelligenceX](https://intelx.io) — deep breach archives

### 2.4 Google Account OSINT
```bash
# GHunt
ghunt email <target@gmail.com>
```
Reveals: full name, profile photo, Maps reviews, YouTube activity, last seen.

---

## Phase 3 — Data Broker Analysis

Key brokers to check manually or via automated opt-out services:

| Broker | URL | Opt-out |
|---|---|---|
| Spokeo | spokeo.com | Manual form |
| BeenVerified | beenverified.com | Email request |
| Whitepages | whitepages.com | Privacy form |
| Intelius | intelius.com | Privacy form |
| PeopleFinder | peoplefinder.com | Email request |

---

## Phase 4 — Metadata Analysis

```bash
# Extract metadata from public files
exiftool document.pdf
exiftool photo.jpg

# Batch extraction from web
metagoofil -d example.com -t pdf,docx -o output/
```

---

## Phase 5 — Threat Modelling

Using the **STRIDE** framework adapted for personal OSINT:

| Threat | Relevance |
|---|---|
| **Spoofing** | Identity impersonation using harvested data |
| **Tampering** | Account takeover via credential stuffing |
| **Repudiation** | Fake profiles using your name/photo |
| **Information Disclosure** | PII exposed via data brokers/breaches |
| **Denial of Service** | Account lockouts via targeted attacks |
| **Elevation of Privilege** | Pivot from social engineering to system access |

---

## Remediation Priority Matrix

```
         HIGH IMPACT
              │
  Broker      │  Breach
  opt-out     │  passwords
              │
LOW ──────────┼────────────── HIGH LIKELIHOOD
  effort      │
              │  Username
  Metadata    │  diversity
  cleanup     │
              │
         LOW IMPACT
```

**Top-right quadrant = highest priority**

---

## References

- NIST SP 800-115 — Technical Guide to Information Security Testing
- OWASP Testing Guide — Information Gathering
- OSINT Framework — https://osintframework.com
- Bellingcat Digital Forensics Guide
