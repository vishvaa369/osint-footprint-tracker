// ─── OSINT Digital Footprint Tracker ───────────────────────────────────────
// Educational tool for mapping personal digital exposure
// Author: vishvaavish369
// ─────────────────────────────────────────────────────────────────────────────

// Clock
function updateClock() {
  const now = new Date();
  document.getElementById('clock').textContent =
    now.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
}
setInterval(updateClock, 1000);
updateClock();

// ─── DATA ────────────────────────────────────────────────────────────────────

const RISK_VECTORS = [
  {
    id: 'broker',
    name: 'Data broker exposure',
    severity: 'critical',
    score: 95,
    desc: 'Major data brokers (Spokeo, BeenVerified, Intelius, Whitepages) aggregate PII from public records, social media, and marketing databases. Your email address is the primary key used to correlate full name, address, phone number, and family members.',
    tools: ['theHarvester', 'IntelligenceX', 'Hunter.io'],
  },
  {
    id: 'username',
    name: 'Username enumeration',
    severity: 'critical',
    score: 92,
    desc: 'A consistent username pattern across platforms allows tools like Sherlock, Maigret, and WhatsMyName to enumerate your presence on 300+ websites in minutes. The numeric suffix creates a strong cross-platform fingerprint.',
    tools: ['Sherlock', 'Maigret', 'WhatsMyName'],
  },
  {
    id: 'breach',
    name: 'Credential breach databases',
    severity: 'high',
    score: 78,
    desc: 'Gmail addresses appear frequently in credential stuffing lists from data breaches. Your email may be present in collections like Collection #1, RockYou2021, or service-specific breaches. This enables password spraying attacks.',
    tools: ['HaveIBeenPwned', 'DeHashed', 'IntelligenceX'],
  },
  {
    id: 'correlation',
    name: 'Cross-platform identity correlation',
    severity: 'high',
    score: 74,
    desc: 'Shared patterns across multiple email addresses (same numeric suffix, similar username base) create a fingerprint that links accounts even when different services are used. Adversaries exploit this to build a complete identity profile.',
    tools: ['Maltego', 'SpiderFoot', 'OSINT Framework'],
  },
  {
    id: 'publicrecords',
    name: 'Public records linkage',
    severity: 'medium',
    score: 55,
    desc: 'Government e-governance portals, alumni directories, and professional registries (especially prevalent in India) may correlate your email address with real name, date of birth, or institutional affiliation.',
    tools: ['Google Dorking', 'Truecaller', 'JustDial'],
  },
  {
    id: 'social',
    name: 'Social engineering surface',
    severity: 'medium',
    score: 50,
    desc: 'Visible email addresses in public commits, forum posts, or social media profiles can be scraped for targeted spear-phishing campaigns. Combined with name and workplace data, attackers can craft convincing pretexts.',
    tools: ['theHarvester', 'LinkedIn OSINT', 'Google Dorking'],
  },
  {
    id: 'google',
    name: 'Google account enumeration',
    severity: 'medium',
    score: 45,
    desc: 'Google accounts expose data through multiple surfaces: Maps reviews (full name/photo), YouTube comments, Calendar sharing links, and Drive public files. Profile visibility settings may be more permissive than expected.',
    tools: ['GHunt', 'Google Advanced Search', 'Namechk'],
  },
  {
    id: 'metadata',
    name: 'File metadata leakage',
    severity: 'low',
    score: 28,
    desc: 'Documents, images, and PDFs shared or uploaded under this email may contain EXIF/metadata revealing device model, GPS location, author name, organisation, and software version — all extractable without opening the file.',
    tools: ['ExifTool', 'FOCA', 'Metagoofil'],
  },
];

const PLATFORMS = [
  { name: 'Gmail / Google', icon: '✉', severity: 'critical', status: 'Exposed — primary attack vector' },
  { name: 'Data brokers', icon: '🗄', severity: 'critical', status: 'PII aggregated at scale' },
  { name: 'Breach databases', icon: '💀', severity: 'critical', status: 'Likely in HIBP / dehashed' },
  { name: 'GitHub', icon: '⌥', severity: 'high', status: 'Commit emails exposed' },
  { name: 'LinkedIn', icon: 'in', severity: 'high', status: 'Name correlation risk' },
  { name: 'Instagram', icon: '◎', severity: 'high', status: 'Handle likely enumerable' },
  { name: 'X / Twitter', icon: '✕', severity: 'high', status: 'Username searchable' },
  { name: 'Reddit', icon: '⊕', severity: 'high', status: 'Post history linkable' },
  { name: 'YouTube', icon: '▶', severity: 'high', status: 'Linked Google account' },
  { name: 'Google Maps', icon: '◉', severity: 'high', status: 'Reviews show full name' },
  { name: 'Discord', icon: '◈', severity: 'low', status: 'Lower public exposure' },
  { name: 'Telegram', icon: '✈', severity: 'low', status: 'Lower public exposure' },
  { name: 'Pastebin / Gists', icon: '⌘', severity: 'low', status: 'Check manually' },
  { name: 'Truecaller (India)', icon: '☏', severity: 'high', status: 'Phone–email correlation' },
];

const CHECKLIST = [
  {
    group: 'IMMEDIATE — Do today',
    items: [
      { id: 'hibp', priority: 'now', title: 'Check both emails on HaveIBeenPwned', desc: 'Visit haveibeenpwned.com for both addresses. Enable breach notifications.', url: 'https://haveibeenpwned.com' },
      { id: 'google-profile', priority: 'now', title: 'Lock down Google public profile', desc: 'myaccount.google.com → Personal info → Remove/restrict name, photo, birthday from public view.' },
      { id: 'maps', priority: 'now', title: 'Audit Google Maps reviews', desc: 'Reviews are public with your full name and photo. Delete or pseudonymize if sensitive.' },
      { id: 'github-email', priority: 'now', title: 'Hide email in GitHub commits', desc: 'Settings → Emails → Enable "Keep my email address private" + "Block command-line pushes that expose my email".' },
    ],
  },
  {
    group: 'SHORT TERM — This week',
    items: [
      { id: 'broker-optout', priority: 'soon', title: 'Opt out of data brokers', desc: 'Submit removal requests to Spokeo, BeenVerified, Whitepages, and Intelius. Use opt-out guides on justdeleteme.com.' },
      { id: 'sherlock', priority: 'soon', title: 'Run Sherlock on your username', desc: 'python3 sherlock vishvaa369 — review every result and delete or privatize unused accounts.' },
      { id: 'unique-usernames', priority: 'soon', title: 'Adopt unique usernames per platform', desc: 'Use a password manager to generate random usernames. Break the cross-platform fingerprint.' },
      { id: 'dehashed', priority: 'soon', title: 'Check DeHashed for credential leaks', desc: 'dehashed.com — search both emails for plaintext or hashed passwords in breach sets.' },
    ],
  },
  {
    group: 'ONGOING — Best practice',
    items: [
      { id: 'email-compartment', priority: 'later', title: 'Compartmentalize email addresses', desc: 'Use separate emails for: personal, service sign-ups, and professional. Consider SimpleLogin or AnonAddy for aliases.' },
      { id: 'metadata', priority: 'later', title: 'Strip metadata from files before sharing', desc: 'Use ExifTool or MAT2 to remove EXIF/document metadata from images and PDFs before uploading publicly.' },
      { id: 'monitor', priority: 'later', title: 'Set Google Alerts for your name + email', desc: 'Alerts for "vishvaavish369" and your real name will surface new exposures as they appear.' },
      { id: 'aliases', priority: 'later', title: 'Use email aliases for all service sign-ups', desc: 'Forward-only aliases (SimpleLogin, iCloud+) mean service breaches never expose your real address.' },
    ],
  },
];

const OSINT_TOOLS = [
  { name: 'Sherlock', use: 'Username enumeration across 300+ platforms' },
  { name: 'Maigret', use: 'Advanced username OSINT with detailed reports' },
  { name: 'theHarvester', use: 'Email & domain reconnaissance' },
  { name: 'GHunt', use: 'Google account OSINT (email → profile)' },
  { name: 'HaveIBeenPwned', use: 'Breach database lookup' },
  { name: 'SpiderFoot', use: 'Automated OSINT collection & correlation' },
  { name: 'Maltego', use: 'Visual link analysis & entity mapping' },
  { name: 'FOCA', use: 'Metadata extraction from public documents' },
  { name: 'Recon-ng', use: 'Web reconnaissance framework' },
  { name: 'ExifTool', use: 'Read/write/strip file metadata' },
];

// ─── STATE ───────────────────────────────────────────────────────────────────

let state = {
  email1: '',
  email2: '',
  username: '',
  checkedItems: new Set(),
  analysisTime: null,
};

// ─── ANALYSIS ────────────────────────────────────────────────────────────────

function runAnalysis() {
  const e1 = document.getElementById('email1').value.trim();
  const e2 = document.getElementById('email2').value.trim();
  const un = document.getElementById('username').value.trim();

  if (!e1) {
    document.getElementById('email1').style.borderColor = 'var(--red)';
    setTimeout(() => (document.getElementById('email1').style.borderColor = ''), 1500);
    return;
  }

  state.email1 = e1;
  state.email2 = e2;
  state.username = un || e1.split('@')[0];
  state.analysisTime = new Date().toISOString().replace('T', ' ').slice(0, 19);

  buildDashboard();
  document.getElementById('inputPanel').classList.add('hidden');
  document.getElementById('dashboard').classList.remove('hidden');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ─── BUILD DASHBOARD ─────────────────────────────────────────────────────────

function buildDashboard() {
  buildRiskSummary();
  buildMetrics();
  buildIdentityCard();
  buildExposureCard();
  buildVectors();
  buildPlatforms();
  buildChecklist();
  buildReport();
}

function buildRiskSummary() {
  const el = document.getElementById('riskSummary');
  el.innerHTML = `
    <div class="target-info">
      <strong>${escHtml(state.email1)}</strong>
      ${state.email2 ? ' + <strong>' + escHtml(state.email2) + '</strong>' : ''}
      <br/><span style="font-size:.7rem">Analysed: ${state.analysisTime} UTC</span>
    </div>
    <div style="text-align:right">
      <div class="risk-label">OVERALL RISK</div>
      <div class="risk-value critical">CRITICAL</div>
    </div>
  `;
}

function buildMetrics() {
  const el = document.getElementById('metricsGrid');
  const criticals = RISK_VECTORS.filter(v => v.severity === 'critical').length;
  const exposedPlatforms = PLATFORMS.filter(p => p.severity === 'critical' || p.severity === 'high').length;
  el.innerHTML = [
    { val: RISK_VECTORS.length, lbl: 'EXPOSURE VECTORS', color: 'var(--red)' },
    { val: criticals, lbl: 'CRITICAL RISKS', color: 'var(--red)' },
    { val: exposedPlatforms, lbl: 'PLATFORMS AT RISK', color: 'var(--amber)' },
    { val: CHECKLIST.flatMap(g => g.items).length, lbl: 'MITIGATIONS', color: 'var(--green)' },
  ].map(m => `
    <div class="metric-card">
      <div class="metric-val" style="color:${m.color}">${m.val}</div>
      <div class="metric-lbl">${m.lbl}</div>
    </div>
  `).join('');
}

function buildIdentityCard() {
  const el = document.getElementById('identityCard');
  const u = state.username;
  const pattern = u.replace(/\d+$/, '') + '[digits]';
  el.innerHTML = `
    <div class="card-title">IDENTITY FINGERPRINT</div>
    ${row('Primary email', state.email1)}
    ${state.email2 ? row('Secondary email', state.email2) : ''}
    ${row('Base username', u)}
    ${row('Username pattern', pattern)}
    ${row('Numeric suffix', u.match(/\d+$/)?.[0] || 'none')}
    ${row('Domain', 'gmail.com')}
  `;
}

function buildExposureCard() {
  const el = document.getElementById('exposureCard');
  el.innerHTML = `
    <div class="card-title">TOP OSINT QUERIES</div>
    ${dork(`"${state.email1}"`)}
    ${state.email2 ? dork(`"${state.email2}"`) : ''}
    ${dork(`site:github.com "${state.username}"`)}
    ${dork(`site:linkedin.com "${state.username}"`)}
    ${dork(`"${state.username}" filetype:pdf`)}
    ${dork(`intext:"${state.email1}" site:pastebin.com`)}
  `;
}

function row(k, v) {
  return `<div class="identity-row"><span class="id-key">${k}</span><span class="id-val">${escHtml(v)}</span></div>`;
}
function dork(q) {
  const url = 'https://google.com/search?q=' + encodeURIComponent(q);
  return `<div class="identity-row"><a href="${url}" target="_blank" style="color:var(--cyan);font-size:.72rem;font-family:var(--mono);text-decoration:none;word-break:break-all">${escHtml(q)} ↗</a></div>`;
}

function buildVectors() {
  const el = document.getElementById('vectorList');
  el.innerHTML = RISK_VECTORS.map(v => `
    <div class="vector-item ${v.severity}">
      <div class="vector-header">
        <span class="vector-name">${v.name}</span>
        <span class="badge ${v.severity}">${v.severity.toUpperCase()}</span>
      </div>
      <div class="bar-track">
        <div class="bar-fill ${v.severity}" style="width:0%" data-width="${v.score}%"></div>
      </div>
      <div class="vector-desc">${v.desc}</div>
      <div style="margin-top:.6rem;font-size:.7rem;color:var(--text-dim)">
        Tools: ${v.tools.map(t => `<span style="color:var(--purple)">${t}</span>`).join(' · ')}
      </div>
    </div>
  `).join('');

  // Animate bars after paint
  setTimeout(() => {
    document.querySelectorAll('.bar-fill[data-width]').forEach(b => {
      b.style.width = b.dataset.width;
    });
  }, 100);
}

function buildPlatforms() {
  const el = document.getElementById('platformGrid');
  el.innerHTML = PLATFORMS.map(p => `
    <div class="platform-card ${p.severity}">
      <div class="plat-name">${p.icon} ${p.name}</div>
      <div class="plat-status ${p.severity}">${p.status}</div>
    </div>
  `).join('');
}

function buildChecklist() {
  const el = document.getElementById('checklistContainer');
  el.innerHTML = CHECKLIST.map(group => `
    <div class="checklist-group">
      <div class="checklist-group-title">${group.group}</div>
      ${group.items.map(item => `
        <div class="check-item ${state.checkedItems.has(item.id) ? 'done' : ''}"
             id="check-${item.id}" onclick="toggleCheck('${item.id}')">
          <div class="check-box">${state.checkedItems.has(item.id) ? '✓' : ''}</div>
          <div style="flex:1">
            <div class="check-title">${item.title}</div>
            <div class="check-desc">${item.desc}</div>
          </div>
          <span class="priority-pill ${item.priority}">${item.priority.toUpperCase()}</span>
        </div>
      `).join('')}
    </div>
  `).join('');
}

function toggleCheck(id) {
  if (state.checkedItems.has(id)) {
    state.checkedItems.delete(id);
  } else {
    state.checkedItems.add(id);
  }
  buildChecklist();
}

function buildReport() {
  const allItems = CHECKLIST.flatMap(g => g.items);
  const done = allItems.filter(i => state.checkedItems.has(i.id)).length;
  const vectors = RISK_VECTORS.map(v =>
    `  [${v.severity.toUpperCase().padEnd(8)}] ${v.name} (${v.score}/100)\n   → ${v.desc.slice(0, 80)}...`
  ).join('\n\n');

  const report = `
╔══════════════════════════════════════════════════════════════════════════════╗
║            OSINT DIGITAL FOOTPRINT THREAT MODEL — EDUCATIONAL              ║
╚══════════════════════════════════════════════════════════════════════════════╝

GENERATED   : ${state.analysisTime} UTC
METHODOLOGY : Passive OSINT / Open-Source Intelligence (No active scanning)
SCOPE       : Personal digital footprint analysis

─── TARGET IDENTIFIERS ──────────────────────────────────────────────────────

  Primary Email  : ${state.email1}${state.email2 ? '\n  Secondary Email: ' + state.email2 : ''}
  Base Username  : ${state.username}
  Domain         : gmail.com
  Pattern        : ${state.username.replace(/\d+$/, '')}[numeric_suffix]

─── EXECUTIVE SUMMARY ───────────────────────────────────────────────────────

  Overall Risk Level  : CRITICAL
  Exposure Vectors    : ${RISK_VECTORS.length} identified
  Platforms at Risk   : ${PLATFORMS.filter(p => p.severity !== 'low').length}
  Mitigations         : ${done}/${allItems.length} completed

  The target's consistent username pattern and dual Gmail presence create a
  high-confidence cross-platform fingerprint. Data broker aggregation and
  likely breach database inclusion represent the highest-priority risks.

─── RISK VECTORS ────────────────────────────────────────────────────────────

${vectors}

─── PLATFORM EXPOSURE ───────────────────────────────────────────────────────

${PLATFORMS.map(p => `  [${p.severity.toUpperCase().padEnd(8)}] ${p.name.padEnd(22)} ${p.status}`).join('\n')}

─── GOOGLE DORK QUERIES ─────────────────────────────────────────────────────

  "${state.email1}"
  site:github.com "${state.username}"
  site:linkedin.com "${state.username}"
  "${state.username}" filetype:pdf
  intext:"${state.email1}" site:pastebin.com
  "${state.email1}" OR "${state.email2 || state.username}"

─── OSINT TOOLS REFERENCED ──────────────────────────────────────────────────

${OSINT_TOOLS.map(t => `  ${t.name.padEnd(18)} ${t.use}`).join('\n')}

─── REMEDIATION CHECKLIST ───────────────────────────────────────────────────

${CHECKLIST.map(g => `\n  ${g.group}\n` + g.items.map(i =>
  `  [${state.checkedItems.has(i.id) ? '✓' : ' '}] [${i.priority.toUpperCase()}] ${i.title}`
).join('\n')).join('\n')}

─── DISCLAIMER ──────────────────────────────────────────────────────────────

  This report was generated for EDUCATIONAL PURPOSES ONLY.
  All analysis is based on passive, open-source methodology.
  Only use these techniques on accounts you own or have explicit
  written authorisation to investigate.
  Unauthorised OSINT investigation may violate computer fraud laws.

─── REFERENCES ──────────────────────────────────────────────────────────────

  OSINT Framework    : https://osintframework.com
  HaveIBeenPwned     : https://haveibeenpwned.com
  Sherlock Project   : https://github.com/sherlock-project/sherlock
  Maigret            : https://github.com/soxoj/maigret
  theHarvester       : https://github.com/laramies/theHarvester
  GHunt              : https://github.com/mxrch/GHunt
  Privacy Guides     : https://www.privacyguides.org

══════════════════════════════════════════════════════════════════════════════
  Report generated by: OSINT Digital Footprint Tracker
  Author: vishvaavish369 | https://github.com/vishvaavish369
══════════════════════════════════════════════════════════════════════════════
`.trim();

  document.getElementById('reportText').textContent = report;
  return report;
}

// ─── TAB SWITCHING ────────────────────────────────────────────────────────────

function showTab(name) {
  document.querySelectorAll('.tab-btn').forEach((btn, i) => {
    const names = ['overview', 'vectors', 'platforms', 'checklist', 'report'];
    btn.classList.toggle('active', names[i] === name);
  });
  document.querySelectorAll('.tab-panel').forEach(p => {
    p.classList.toggle('hidden', p.id !== 'tab-' + name);
    p.classList.toggle('active', p.id === 'tab-' + name);
  });
  if (name === 'report') buildReport();
}

// ─── REPORT ACTIONS ───────────────────────────────────────────────────────────

function copyReport() {
  const text = document.getElementById('reportText').textContent;
  navigator.clipboard.writeText(text).then(() => {
    const btn = document.querySelector('.action-btn');
    const orig = btn.textContent;
    btn.textContent = '✓ COPIED';
    btn.style.color = 'var(--green)';
    setTimeout(() => { btn.textContent = orig; btn.style.color = ''; }, 2000);
  });
}

function downloadReport() {
  const text = document.getElementById('reportText').textContent;
  const filename = `osint_report_${state.username}_${Date.now()}.txt`;
  const blob = new Blob([text], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

function printReport() { window.print(); }

// ─── UTILS ────────────────────────────────────────────────────────────────────

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// Allow Enter key on inputs
document.addEventListener('DOMContentLoaded', () => {
  ['email1', 'email2', 'username'].forEach(id => {
    document.getElementById(id)?.addEventListener('keydown', e => {
      if (e.key === 'Enter') runAnalysis();
    });
  });
});
